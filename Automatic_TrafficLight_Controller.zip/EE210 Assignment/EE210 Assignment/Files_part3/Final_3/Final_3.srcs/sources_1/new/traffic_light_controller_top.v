`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.10.2025 11:29:15
// Design Name: 
// Module Name: traffic_light_controller_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module traffic_light_controller_top (
    
    input  wire clk,     
    input  wire reset,   
    input  wire sensor,  
    
    
    output wire R1_G, R1_Y, R1_R, 
    output wire R2_G, R2_Y, R2_R  
);


wire timer_done;         
wire timer_start;        
wire [1:0] timer_select; 


reg [10:0] max_count_val; 



localparam T_5S  = 11'd250;  
localparam T_20S = 11'd1000; 
localparam T_30S = 11'd1500; 


localparam SEL_30S = 2'b00;
localparam SEL_20S = 2'b01;
localparam SEL_5S  = 2'b10;



always @(*) begin
    case (timer_select)
        SEL_30S: max_count_val = T_30S;
        SEL_20S: max_count_val = T_20S;
        SEL_5S:  max_count_val = T_5S;
        default: max_count_val = T_5S; 
    endcase
end



traffic_controller U_FSM (
    .clk(clk),
    .reset(reset),
    .sensor(sensor),
    .timer_done(timer_done),
    
    .R1_G(R1_G), .R1_Y(R1_Y), .R1_R(R1_R),
    .R2_G(R2_G), .R2_Y(R2_Y), .R2_R(R2_R),
    
    .timer_start(timer_start),
    .timer_select(timer_select)
);




wire counter_reset = reset | timer_start;


proj_2 U_COUNTER (
    .clk(clk),
    .reset(counter_reset),          
    .max_count_val(max_count_val),  
    .timeout(timer_done)            
);

endmodule