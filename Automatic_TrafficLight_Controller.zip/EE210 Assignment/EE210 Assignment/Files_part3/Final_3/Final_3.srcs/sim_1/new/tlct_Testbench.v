`timescale 1ns / 1ps

module traffic_control_top_tb;


parameter CLK_PERIOD_PS = 20_000_000; 

reg  clk;
reg  reset;
reg  sensor;

wire R1_G, R1_Y, R1_R;
wire R2_G, R2_Y, R2_R;

parameter T_30S_CYCLES = 1500;
parameter T_20S_CYCLES = 1000;
parameter T_5S_CYCLES  = 250;


traffic_light_controller_top DUT (
    .clk(clk),
    .reset(reset),
    .sensor(sensor),
    .R1_G(R1_G),
    .R1_Y(R1_Y),
    .R1_R(R1_R),
    .R2_G(R2_G),
    .R2_Y(R2_Y),
    .R2_R(R2_R)
);


initial begin
    clk = 0;
    
    forever #(CLK_PERIOD_PS / 2) clk = ~clk;
end



initial begin
    
    
    
    reset = 1'b1;
    sensor = 1'b0;
    @(posedge clk);
    
    
    reset = 1'b0;
    @(posedge clk); 
    
    

    
    sensor = 1'b1; 
    
    // Wait for Main Green (30s)
    repeat (T_30S_CYCLES) @(posedge clk);
    @(posedge clk); // Timer done pulse
    

    // Wait for Main Yellow (5s)
    repeat (T_5S_CYCLES) @(posedge clk);
    @(posedge clk);
    

    // Wait for Side Green (20s)
    repeat (T_20S_CYCLES) @(posedge clk);
    @(posedge clk);
    
    
    // Wait for Side Yellow (5s)
    repeat (T_5S_CYCLES) @(posedge clk);
    @(posedge clk);
    
    sensor = 1'b0; 

    
    repeat (T_30S_CYCLES) @(posedge clk);
    @(posedge clk);
    

    
    repeat (T_5S_CYCLES) @(posedge clk);
    @(posedge clk);
    
  
    
    
    repeat (T_5S_CYCLES) @(posedge clk); 

    
    $finish;
end

endmodule