# ----------------------------------------------------------------------------
# Traffic Light Controller Constraints for ZedBoard
# This file extracts necessary pins for I/O and sets the timing constraint.
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# 1. CLOCK CONSTRAINT (REQUIRED)
# ----------------------------------------------------------------------------
# Pin Y9 is the Zynq's PL Clock input, running at 100 MHz on the ZedBoard.
set_property PACKAGE_PIN Y9 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk] [cite: 161]
create_clock -period 10.000 -name sys_clk [get_ports clk]

# ----------------------------------------------------------------------------
# 2. INPUT CONSTRAINTS (Reset and Sensor)
# ----------------------------------------------------------------------------
# 'reset' is mapped to Center Push Button (BTNC) [cite: 112]
set_property PACKAGE_PIN P16 [get_ports reset] [cite: 112]
set_property IOSTANDARD LVCMOS33 [get_ports reset] [cite: 156]

# 'sensor' is mapped to DIP Switch SW0 [cite: 119]
set_property PACKAGE_PIN F22 [get_ports sensor] [cite: 119]
# SW0 is in Bank 35, which defaults to LVCMOS18, but LVCMOS33 is also a common choice for switches.
set_property IOSTANDARD LVCMOS18 [get_ports sensor] [cite: 160]

# Recommended asynchronous reset constraint
set_property ASYNC_REG true [get_cells *reset*]

# ----------------------------------------------------------------------------
# 3. OUTPUT CONSTRAINTS (Traffic Lights - Mapped to User LEDs LD0-LD5)
#    All LEDs are in Bank 33, fixed to LVCMOS33. [cite: 156]
# ----------------------------------------------------------------------------

# R1_G (Main Green) -> LD0 [cite: 103]
set_property PACKAGE_PIN T22 [get_ports R1_G] [cite: 103]
set_property IOSTANDARD LVCMOS33 [get_ports R1_G] [cite: 156]

# R1_Y (Main Yellow) -> LD1 [cite: 103]
set_property PACKAGE_PIN T21 [get_ports R1_Y] [cite: 103]
set_property IOSTANDARD LVCMOS33 [get_ports R1_Y] [cite: 156]

# R1_R (Main Red) -> LD2 [cite: 104]
set_property PACKAGE_PIN U22 [get_ports R1_R] [cite: 104]
set_property IOSTANDARD LVCMOS33 [get_ports R1_R] [cite: 156]

# R2_G (Side Green) -> LD3 [cite: 104]
set_property PACKAGE_PIN U21 [get_ports R2_G] [cite: 104]
set_property IOSTANDARD LVCMOS33 [get_ports R2_G] [cite: 156]

# R2_Y (Side Yellow) -> LD4 [cite: 104]
set_property PACKAGE_PIN V22 [get_ports R2_Y] [cite: 104]
set_property IOSTANDARD LVCMOS33 [get_ports R2_Y] [cite: 156]

# R2_R (Side Red) -> LD5 [cite: 104]
set_property PACKAGE_PIN W22 [get_ports R2_R] [cite: 104]
set_property IOSTANDARD LVCMOS33 [get_ports R2_R] [cite: 156]

# ----------------------------------------------------------------------------
# 4. Bank-Wide IOSTANDARD Settings (Uncommented for completeness)
# ----------------------------------------------------------------------------
# Note that the bank voltage for IO Bank 33 is fixed to 3.3V on ZedBoard. [cite: 156]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]]; [cite: 156]

# Set the bank voltage for IO Bank 34 to 1.8V by default. [cite: 158]
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 34]]; [cite: 158]

# Set the bank voltage for IO Bank 35 to 1.8V by default. [cite: 160]
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]]; [cite: 160]

# Note that the bank voltage for IO Bank 13 is fixed to 3.3V on ZedBoard. [cite: 161]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]]; [cite: 161]

set_property PACKAGE_PIN P16 [get_ports reset]
set_property PACKAGE_PIN F22 [get_ports sensor]
set_property PACKAGE_PIN T22 [get_ports R1_G]
set_property PACKAGE_PIN T21 [get_ports R1_R]
set_property PACKAGE_PIN U22 [get_ports R1_Y]
set_property PACKAGE_PIN U21 [get_ports R2_G]
set_property PACKAGE_PIN V22 [get_ports R2_R]
set_property PACKAGE_PIN W22 [get_ports R2_Y]

# These outputs (LEDs) MUST be LVCMOS33 (Bank 33)
set_property IOSTANDARD LVCMOS33 [get_ports R1_G]
set_property IOSTANDARD LVCMOS33 [get_ports R1_R]
set_property IOSTANDARD LVCMOS33 [get_ports R1_Y]
set_property IOSTANDARD LVCMOS33 [get_ports R2_G]
set_property IOSTANDARD LVCMOS33 [get_ports R2_R]
set_property IOSTANDARD LVCMOS33 [get_ports R2_Y]

# Reset Button (P16 in Bank 34) set to LVCMOS33
set_property IOSTANDARD LVCMOS33 [get_ports reset]

# Sensor Switch (F22 in Bank 35) set to LVCMOS18 (This one is correct)
set_property IOSTANDARD LVCMOS18 [get_ports sensor]

# ... (Also ensure the PACKAGE_PIN lines are correct)