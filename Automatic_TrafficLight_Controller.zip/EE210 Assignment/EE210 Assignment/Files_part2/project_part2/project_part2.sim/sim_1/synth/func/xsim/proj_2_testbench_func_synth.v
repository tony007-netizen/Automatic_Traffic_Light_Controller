// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Tue Oct 28 01:34:25 2025
// Host        : Tanmay_Asus running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file
//               C:/VivadoProjects/project_part2/project_part2.sim/sim_1/synth/func/xsim/proj_2_testbench_func_synth.v
// Design      : proj_2
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* NotValidForBitStream *)
module proj_2
   (clk,
    reset,
    max_count_val,
    timeout);
  input clk;
  input reset;
  input [10:0]max_count_val;
  output timeout;

  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire \counter_reg[10]_i_1_n_0 ;
  wire \counter_reg[10]_i_3_n_0 ;
  wire [10:0]counter_reg_reg;
  wire [10:0]max_count_val;
  wire [10:0]max_count_val_IBUF;
  wire [10:0]p_0_in;
  wire reset;
  wire reset_IBUF;
  wire timeout;
  wire timeout_OBUF;
  wire timeout_i_2_n_0;
  wire timeout_i_3_n_0;
  wire timeout_i_4_n_0;
  wire timeout_i_5_n_0;
  wire timeout_reg_i_1_n_0;
  wire timeout_reg_i_1_n_1;
  wire timeout_reg_i_1_n_2;
  wire timeout_reg_i_1_n_3;
  wire [3:0]NLW_timeout_reg_i_1_O_UNCONNECTED;

  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  LUT1 #(
    .INIT(2'h1)) 
    \counter_reg[0]_i_1 
       (.I0(counter_reg_reg[0]),
        .O(p_0_in[0]));
  LUT2 #(
    .INIT(4'hE)) 
    \counter_reg[10]_i_1 
       (.I0(timeout_reg_i_1_n_0),
        .I1(reset_IBUF),
        .O(\counter_reg[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \counter_reg[10]_i_2 
       (.I0(counter_reg_reg[8]),
        .I1(counter_reg_reg[6]),
        .I2(\counter_reg[10]_i_3_n_0 ),
        .I3(counter_reg_reg[7]),
        .I4(counter_reg_reg[9]),
        .I5(counter_reg_reg[10]),
        .O(p_0_in[10]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \counter_reg[10]_i_3 
       (.I0(counter_reg_reg[5]),
        .I1(counter_reg_reg[3]),
        .I2(counter_reg_reg[1]),
        .I3(counter_reg_reg[0]),
        .I4(counter_reg_reg[2]),
        .I5(counter_reg_reg[4]),
        .O(\counter_reg[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \counter_reg[1]_i_1 
       (.I0(counter_reg_reg[0]),
        .I1(counter_reg_reg[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \counter_reg[2]_i_1 
       (.I0(counter_reg_reg[0]),
        .I1(counter_reg_reg[1]),
        .I2(counter_reg_reg[2]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \counter_reg[3]_i_1 
       (.I0(counter_reg_reg[1]),
        .I1(counter_reg_reg[0]),
        .I2(counter_reg_reg[2]),
        .I3(counter_reg_reg[3]),
        .O(p_0_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \counter_reg[4]_i_1 
       (.I0(counter_reg_reg[2]),
        .I1(counter_reg_reg[0]),
        .I2(counter_reg_reg[1]),
        .I3(counter_reg_reg[3]),
        .I4(counter_reg_reg[4]),
        .O(p_0_in[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \counter_reg[5]_i_1 
       (.I0(counter_reg_reg[3]),
        .I1(counter_reg_reg[1]),
        .I2(counter_reg_reg[0]),
        .I3(counter_reg_reg[2]),
        .I4(counter_reg_reg[4]),
        .I5(counter_reg_reg[5]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \counter_reg[6]_i_1 
       (.I0(\counter_reg[10]_i_3_n_0 ),
        .I1(counter_reg_reg[6]),
        .O(p_0_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \counter_reg[7]_i_1 
       (.I0(\counter_reg[10]_i_3_n_0 ),
        .I1(counter_reg_reg[6]),
        .I2(counter_reg_reg[7]),
        .O(p_0_in[7]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \counter_reg[8]_i_1 
       (.I0(counter_reg_reg[6]),
        .I1(\counter_reg[10]_i_3_n_0 ),
        .I2(counter_reg_reg[7]),
        .I3(counter_reg_reg[8]),
        .O(p_0_in[8]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \counter_reg[9]_i_1 
       (.I0(counter_reg_reg[7]),
        .I1(\counter_reg[10]_i_3_n_0 ),
        .I2(counter_reg_reg[6]),
        .I3(counter_reg_reg[8]),
        .I4(counter_reg_reg[9]),
        .O(p_0_in[9]));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(counter_reg_reg[0]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[10]),
        .Q(counter_reg_reg[10]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(counter_reg_reg[1]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(counter_reg_reg[2]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(counter_reg_reg[3]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(counter_reg_reg[4]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(counter_reg_reg[5]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(counter_reg_reg[6]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[7]),
        .Q(counter_reg_reg[7]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(counter_reg_reg[8]),
        .R(\counter_reg[10]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \counter_reg_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(counter_reg_reg[9]),
        .R(\counter_reg[10]_i_1_n_0 ));
  IBUF \max_count_val_IBUF[0]_inst 
       (.I(max_count_val[0]),
        .O(max_count_val_IBUF[0]));
  IBUF \max_count_val_IBUF[10]_inst 
       (.I(max_count_val[10]),
        .O(max_count_val_IBUF[10]));
  IBUF \max_count_val_IBUF[1]_inst 
       (.I(max_count_val[1]),
        .O(max_count_val_IBUF[1]));
  IBUF \max_count_val_IBUF[2]_inst 
       (.I(max_count_val[2]),
        .O(max_count_val_IBUF[2]));
  IBUF \max_count_val_IBUF[3]_inst 
       (.I(max_count_val[3]),
        .O(max_count_val_IBUF[3]));
  IBUF \max_count_val_IBUF[4]_inst 
       (.I(max_count_val[4]),
        .O(max_count_val_IBUF[4]));
  IBUF \max_count_val_IBUF[5]_inst 
       (.I(max_count_val[5]),
        .O(max_count_val_IBUF[5]));
  IBUF \max_count_val_IBUF[6]_inst 
       (.I(max_count_val[6]),
        .O(max_count_val_IBUF[6]));
  IBUF \max_count_val_IBUF[7]_inst 
       (.I(max_count_val[7]),
        .O(max_count_val_IBUF[7]));
  IBUF \max_count_val_IBUF[8]_inst 
       (.I(max_count_val[8]),
        .O(max_count_val_IBUF[8]));
  IBUF \max_count_val_IBUF[9]_inst 
       (.I(max_count_val[9]),
        .O(max_count_val_IBUF[9]));
  IBUF reset_IBUF_inst
       (.I(reset),
        .O(reset_IBUF));
  OBUF timeout_OBUF_inst
       (.I(timeout_OBUF),
        .O(timeout));
  LUT4 #(
    .INIT(16'h9009)) 
    timeout_i_2
       (.I0(counter_reg_reg[9]),
        .I1(max_count_val_IBUF[9]),
        .I2(counter_reg_reg[10]),
        .I3(max_count_val_IBUF[10]),
        .O(timeout_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    timeout_i_3
       (.I0(counter_reg_reg[6]),
        .I1(max_count_val_IBUF[6]),
        .I2(max_count_val_IBUF[8]),
        .I3(counter_reg_reg[8]),
        .I4(max_count_val_IBUF[7]),
        .I5(counter_reg_reg[7]),
        .O(timeout_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    timeout_i_4
       (.I0(counter_reg_reg[3]),
        .I1(max_count_val_IBUF[3]),
        .I2(max_count_val_IBUF[5]),
        .I3(counter_reg_reg[5]),
        .I4(max_count_val_IBUF[4]),
        .I5(counter_reg_reg[4]),
        .O(timeout_i_4_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    timeout_i_5
       (.I0(counter_reg_reg[0]),
        .I1(max_count_val_IBUF[0]),
        .I2(max_count_val_IBUF[2]),
        .I3(counter_reg_reg[2]),
        .I4(max_count_val_IBUF[1]),
        .I5(counter_reg_reg[1]),
        .O(timeout_i_5_n_0));
  FDRE #(
    .INIT(1'b0)) 
    timeout_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(timeout_reg_i_1_n_0),
        .Q(timeout_OBUF),
        .R(reset_IBUF));
  CARRY4 timeout_reg_i_1
       (.CI(1'b0),
        .CO({timeout_reg_i_1_n_0,timeout_reg_i_1_n_1,timeout_reg_i_1_n_2,timeout_reg_i_1_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_timeout_reg_i_1_O_UNCONNECTED[3:0]),
        .S({timeout_i_2_n_0,timeout_i_3_n_0,timeout_i_4_n_0,timeout_i_5_n_0}));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
