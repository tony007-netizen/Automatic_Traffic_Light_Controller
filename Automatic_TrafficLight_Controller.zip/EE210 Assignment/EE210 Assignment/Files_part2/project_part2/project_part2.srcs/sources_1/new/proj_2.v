`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 28.10.2025 00:00:37
// Design Name: 
// Module Name: proj_2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module proj_2 (
    input clk,
    input reset,
    input [10:0] max_count_val,
    output reg timeout
);

reg [10:0] counter_reg;

always @(posedge clk) begin
    if (reset) begin
        counter_reg <= 11'd0;
        timeout     <= 1'b0;
    end else begin
        if (counter_reg == max_count_val) begin
            timeout     <= 1'b1;
            counter_reg <= 11'd0;
        end else begin
            counter_reg <= counter_reg + 11'd1;
            timeout     <= 1'b0;
        end
    end
end

endmodule
