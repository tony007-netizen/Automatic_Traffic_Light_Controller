`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 28.10.2025 00:06:22
// Design Name: 
// Module Name: proj_2_testbench
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module proj_2_testbench;

    reg clk;
    reg reset;
    reg [10:0] max_count_val;
    wire timeout;
    
    parameter CLK_PERIOD = 10;
    
    parameter T_5S  = 11'd250;
    parameter T_20S = 11'd1000;
    parameter T_30S = 11'd1500;
    
    proj_2 uut (
        .clk(clk),
        .reset(reset),
        .max_count_val(max_count_val),
        .timeout(timeout)
    );

    initial begin
        clk = 1'b0;
        forever #(CLK_PERIOD / 2) clk = ~clk;
    end

    initial begin
        reset         = 1'b1;
        max_count_val = T_30S;
        
        
        
        @(posedge clk);
        reset = 1'b0;
       
        
        max_count_val = T_5S;
        
        repeat (T_5S) @(posedge clk);
        @(posedge clk);
        
        
        
        max_count_val = T_30S;
       
        repeat (T_30S) @(posedge clk);
        @(posedge clk); 
        
       
        
        max_count_val = T_20S;
        
        repeat (T_20S) @(posedge clk);
        @(posedge clk); 
        
        
        
       
        $finish;
    end
    
endmodule
