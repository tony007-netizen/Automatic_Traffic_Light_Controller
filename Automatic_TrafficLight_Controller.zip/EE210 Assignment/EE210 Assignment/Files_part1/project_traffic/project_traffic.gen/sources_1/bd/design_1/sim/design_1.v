//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
//Date        : Tue Oct 28 17:11:36 2025
//Host        : HP running 64-bit major release  (build 9200)
//Command     : generate_target design_1.bd
//Design      : design_1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=3,numReposBlks=3,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,da_board_cnt=1,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "design_1.hwdef" *) 
module design_1
   (R1_G,
    R1_R,
    R1_Y,
    R2_G,
    R2_R,
    R2_Y,
    reset,
    sensor,
    sys_clock,
    timer_done,
    timer_select,
    timer_start);
  output R1_G;
  output R1_R;
  output R1_Y;
  output R2_G;
  output R2_R;
  output R2_Y;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESET RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESET, INSERT_VIP 0, POLARITY ACTIVE_HIGH" *) input reset;
  input sensor;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.SYS_CLOCK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.SYS_CLOCK, CLK_DOMAIN design_1_sys_clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input sys_clock;
  input timer_done;
  output [1:0]timer_select;
  output timer_start;

  wire R1_G;
  wire R1_R;
  wire R1_Y;
  wire R2_G;
  wire R2_R;
  wire R2_Y;
  wire clk_wiz_0_clk_out1;
  wire [0:0]proc_sys_reset_0_peripheral_reset;
  wire reset;
  wire sensor;
  wire sys_clock;
  wire timer_done;
  wire [1:0]timer_select;
  wire timer_start;

  design_1_clk_wiz_0_0 clk_wiz_0
       (.clk_in1(sys_clock),
        .clk_out1(clk_wiz_0_clk_out1));
  design_1_proc_sys_reset_0_0 proc_sys_reset_0
       (.aux_reset_in(1'b1),
        .dcm_locked(1'b1),
        .ext_reset_in(reset),
        .mb_debug_sys_rst(1'b0),
        .peripheral_reset(proc_sys_reset_0_peripheral_reset),
        .slowest_sync_clk(clk_wiz_0_clk_out1));
  design_1_traffic_controller_0_0 traffic_controller_0
       (.R1_G(R1_G),
        .R1_R(R1_R),
        .R1_Y(R1_Y),
        .R2_G(R2_G),
        .R2_R(R2_R),
        .R2_Y(R2_Y),
        .clk(clk_wiz_0_clk_out1),
        .reset(proc_sys_reset_0_peripheral_reset),
        .sensor(sensor),
        .timer_done(timer_done),
        .timer_select(timer_select),
        .timer_start(timer_start));
endmodule
