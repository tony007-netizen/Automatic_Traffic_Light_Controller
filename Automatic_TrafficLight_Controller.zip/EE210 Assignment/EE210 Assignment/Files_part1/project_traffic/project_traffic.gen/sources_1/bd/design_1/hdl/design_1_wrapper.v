//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
//Date        : Tue Oct 28 17:11:36 2025
//Host        : HP running 64-bit major release  (build 9200)
//Command     : generate_target design_1_wrapper.bd
//Design      : design_1_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_1_wrapper
   (R1_G,
    R1_R,
    R1_Y,
    R2_G,
    R2_R,
    R2_Y,
    reset,
    sensor,
    sys_clock,
    timer_done,
    timer_select,
    timer_start);
  output R1_G;
  output R1_R;
  output R1_Y;
  output R2_G;
  output R2_R;
  output R2_Y;
  input reset;
  input sensor;
  input sys_clock;
  input timer_done;
  output [1:0]timer_select;
  output timer_start;

  wire R1_G;
  wire R1_R;
  wire R1_Y;
  wire R2_G;
  wire R2_R;
  wire R2_Y;
  wire reset;
  wire sensor;
  wire sys_clock;
  wire timer_done;
  wire [1:0]timer_select;
  wire timer_start;

  design_1 design_1_i
       (.R1_G(R1_G),
        .R1_R(R1_R),
        .R1_Y(R1_Y),
        .R2_G(R2_G),
        .R2_R(R2_R),
        .R2_Y(R2_Y),
        .reset(reset),
        .sensor(sensor),
        .sys_clock(sys_clock),
        .timer_done(timer_done),
        .timer_select(timer_select),
        .timer_start(timer_start));
endmodule
