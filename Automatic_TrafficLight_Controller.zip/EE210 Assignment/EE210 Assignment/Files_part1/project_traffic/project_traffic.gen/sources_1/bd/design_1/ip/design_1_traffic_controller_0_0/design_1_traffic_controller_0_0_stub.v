// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Tue Oct 28 17:12:33 2025
// Host        : HP running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/vivado_projects/project_traffic/project_traffic.gen/sources_1/bd/design_1/ip/design_1_traffic_controller_0_0/design_1_traffic_controller_0_0_stub.v
// Design      : design_1_traffic_controller_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "design_1_traffic_controller_0_0,traffic_controller,{}" *) (* CORE_GENERATION_INFO = "design_1_traffic_controller_0_0,traffic_controller,{x_ipProduct=Vivado 2025.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=traffic_controller,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "traffic_controller,Vivado 2025.1" *) 
module design_1_traffic_controller_0_0(clk, reset, sensor, timer_done, R1_G, R1_Y, R1_R, R2_G, 
  R2_Y, R2_R, timer_start, timer_select)
/* synthesis syn_black_box black_box_pad_pin="reset,sensor,timer_done,R1_G,R1_Y,R1_R,R2_G,R2_Y,R2_R,timer_start,timer_select[1:0]" */
/* synthesis syn_force_seq_prim="clk" */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input clk /* synthesis syn_isclock = 1 */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 reset RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input reset;
  input sensor;
  input timer_done;
  output R1_G;
  output R1_Y;
  output R1_R;
  output R2_G;
  output R2_Y;
  output R2_R;
  output timer_start;
  output [1:0]timer_select;
endmodule
