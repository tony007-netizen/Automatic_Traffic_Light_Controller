-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
-- Date        : Tue Oct 28 17:12:33 2025
-- Host        : HP running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/vivado_projects/project_traffic/project_traffic.gen/sources_1/bd/design_1/ip/design_1_traffic_controller_0_0/design_1_traffic_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_traffic_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_traffic_controller_0_0_traffic_controller is
  port (
    R1_Y : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 1 downto 0 );
    timer_select : out STD_LOGIC_VECTOR ( 0 to 0 );
    timer_start : out STD_LOGIC;
    R2_Y : out STD_LOGIC;
    R1_G : out STD_LOGIC;
    R2_R : out STD_LOGIC;
    timer_done : in STD_LOGIC;
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    sensor : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_traffic_controller_0_0_traffic_controller : entity is "traffic_controller";
end design_1_traffic_controller_0_0_traffic_controller;

architecture STRUCTURE of design_1_traffic_controller_0_0_traffic_controller is
  signal \FSM_sequential_current_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal current_state : STD_LOGIC_VECTOR ( 0 to 0 );
  signal next_state : STD_LOGIC_VECTOR ( 2 downto 1 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_current_state[0]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \FSM_sequential_current_state[1]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \FSM_sequential_current_state[2]_i_1\ : label is "soft_lutpair0";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_current_state_reg[0]\ : label is "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000";
  attribute FSM_ENCODED_STATES of \FSM_sequential_current_state_reg[1]\ : label is "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000";
  attribute FSM_ENCODED_STATES of \FSM_sequential_current_state_reg[2]\ : label is "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000";
  attribute SOFT_HLUTNM of R1_G_INST_0 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of R1_Y_INST_0 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of R2_Y_INST_0 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \timer_select[0]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of timer_start_INST_0 : label is "soft_lutpair2";
begin
  Q(1 downto 0) <= \^q\(1 downto 0);
\FSM_sequential_current_state[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => current_state(0),
      I1 => timer_done,
      O => \FSM_sequential_current_state[0]_i_1_n_0\
    );
\FSM_sequential_current_state[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \^q\(0),
      I1 => current_state(0),
      I2 => timer_done,
      O => next_state(1)
    );
\FSM_sequential_current_state[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6A2AAAAA"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => timer_done,
      I3 => sensor,
      I4 => current_state(0),
      O => next_state(2)
    );
\FSM_sequential_current_state_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => \FSM_sequential_current_state[0]_i_1_n_0\,
      Q => current_state(0)
    );
\FSM_sequential_current_state_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => next_state(1),
      Q => \^q\(0)
    );
\FSM_sequential_current_state_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => clk,
      CE => '1',
      CLR => reset,
      D => next_state(2),
      Q => \^q\(1)
    );
R1_G_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      O => R1_G
    );
R1_Y_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      O => R1_Y
    );
R2_R_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q\(1),
      O => R2_R
    );
R2_Y_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      O => R2_Y
    );
\timer_select[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      O => timer_select(0)
    );
timer_start_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => current_state(0),
      O => timer_start
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_traffic_controller_0_0 is
  port (
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    sensor : in STD_LOGIC;
    timer_done : in STD_LOGIC;
    R1_G : out STD_LOGIC;
    R1_Y : out STD_LOGIC;
    R1_R : out STD_LOGIC;
    R2_G : out STD_LOGIC;
    R2_Y : out STD_LOGIC;
    R2_R : out STD_LOGIC;
    timer_start : out STD_LOGIC;
    timer_select : out STD_LOGIC_VECTOR ( 1 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_traffic_controller_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_traffic_controller_0_0 : entity is "design_1_traffic_controller_0_0,traffic_controller,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_traffic_controller_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_traffic_controller_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_traffic_controller_0_0 : entity is "traffic_controller,Vivado 2025.1";
end design_1_traffic_controller_0_0;

architecture STRUCTURE of design_1_traffic_controller_0_0 is
  signal \^timer_select\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of reset : signal is "xilinx.com:signal:reset:1.0 reset RST";
  attribute X_INTERFACE_MODE of reset : signal is "slave";
  attribute X_INTERFACE_PARAMETER of reset : signal is "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH, INSERT_VIP 0";
begin
  R2_G <= \^timer_select\(0);
  timer_select(1 downto 0) <= \^timer_select\(1 downto 0);
inst: entity work.design_1_traffic_controller_0_0_traffic_controller
     port map (
      Q(1) => R1_R,
      Q(0) => \^timer_select\(1),
      R1_G => R1_G,
      R1_Y => R1_Y,
      R2_R => R2_R,
      R2_Y => R2_Y,
      clk => clk,
      reset => reset,
      sensor => sensor,
      timer_done => timer_done,
      timer_select(0) => \^timer_select\(0),
      timer_start => timer_start
    );
end STRUCTURE;
