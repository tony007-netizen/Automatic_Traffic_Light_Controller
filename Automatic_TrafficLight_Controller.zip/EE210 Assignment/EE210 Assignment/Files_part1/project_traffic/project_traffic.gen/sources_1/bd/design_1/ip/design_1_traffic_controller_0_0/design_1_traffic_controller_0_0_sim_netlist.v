// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Tue Oct 28 17:12:33 2025
// Host        : HP running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/vivado_projects/project_traffic/project_traffic.gen/sources_1/bd/design_1/ip/design_1_traffic_controller_0_0/design_1_traffic_controller_0_0_sim_netlist.v
// Design      : design_1_traffic_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_traffic_controller_0_0,traffic_controller,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "traffic_controller,Vivado 2025.1" *) 
(* NotValidForBitStream *)
module design_1_traffic_controller_0_0
   (clk,
    reset,
    sensor,
    timer_done,
    R1_G,
    R1_Y,
    R1_R,
    R2_G,
    R2_Y,
    R2_R,
    timer_start,
    timer_select);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 reset RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME reset, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input reset;
  input sensor;
  input timer_done;
  output R1_G;
  output R1_Y;
  output R1_R;
  output R2_G;
  output R2_Y;
  output R2_R;
  output timer_start;
  output [1:0]timer_select;

  wire R1_G;
  wire R1_R;
  wire R1_Y;
  wire R2_R;
  wire R2_Y;
  wire clk;
  wire reset;
  wire sensor;
  wire timer_done;
  wire [1:0]timer_select;
  wire timer_start;

  assign R2_G = timer_select[0];
  design_1_traffic_controller_0_0_traffic_controller inst
       (.Q({R1_R,timer_select[1]}),
        .R1_G(R1_G),
        .R1_Y(R1_Y),
        .R2_R(R2_R),
        .R2_Y(R2_Y),
        .clk(clk),
        .reset(reset),
        .sensor(sensor),
        .timer_done(timer_done),
        .timer_select(timer_select[0]),
        .timer_start(timer_start));
endmodule

(* ORIG_REF_NAME = "traffic_controller" *) 
module design_1_traffic_controller_0_0_traffic_controller
   (R1_Y,
    Q,
    timer_select,
    timer_start,
    R2_Y,
    R1_G,
    R2_R,
    timer_done,
    clk,
    reset,
    sensor);
  output R1_Y;
  output [1:0]Q;
  output [0:0]timer_select;
  output timer_start;
  output R2_Y;
  output R1_G;
  output R2_R;
  input timer_done;
  input clk;
  input reset;
  input sensor;

  wire \FSM_sequential_current_state[0]_i_1_n_0 ;
  wire [1:0]Q;
  wire R1_G;
  wire R1_Y;
  wire R2_R;
  wire R2_Y;
  wire clk;
  wire [0:0]current_state;
  wire [2:1]next_state;
  wire reset;
  wire sensor;
  wire timer_done;
  wire [0:0]timer_select;
  wire timer_start;

  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \FSM_sequential_current_state[0]_i_1 
       (.I0(current_state),
        .I1(timer_done),
        .O(\FSM_sequential_current_state[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \FSM_sequential_current_state[1]_i_1 
       (.I0(Q[0]),
        .I1(current_state),
        .I2(timer_done),
        .O(next_state[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h6A2AAAAA)) 
    \FSM_sequential_current_state[2]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(timer_done),
        .I3(sensor),
        .I4(current_state),
        .O(next_state[2]));
  (* FSM_ENCODED_STATES = "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000" *) 
  FDCE \FSM_sequential_current_state_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(\FSM_sequential_current_state[0]_i_1_n_0 ),
        .Q(current_state));
  (* FSM_ENCODED_STATES = "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000" *) 
  FDCE \FSM_sequential_current_state_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(next_state[1]),
        .Q(Q[0]));
  (* FSM_ENCODED_STATES = "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000" *) 
  FDCE \FSM_sequential_current_state_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(next_state[2]),
        .Q(Q[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h1)) 
    R1_G_INST_0
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(R1_G));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h2)) 
    R1_Y_INST_0
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(R1_Y));
  LUT1 #(
    .INIT(2'h1)) 
    R2_R_INST_0
       (.I0(Q[1]),
        .O(R2_R));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h8)) 
    R2_Y_INST_0
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(R2_Y));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \timer_select[0]_INST_0 
       (.I0(Q[1]),
        .I1(Q[0]),
        .O(timer_select));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT1 #(
    .INIT(2'h1)) 
    timer_start_INST_0
       (.I0(current_state),
        .O(timer_start));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
