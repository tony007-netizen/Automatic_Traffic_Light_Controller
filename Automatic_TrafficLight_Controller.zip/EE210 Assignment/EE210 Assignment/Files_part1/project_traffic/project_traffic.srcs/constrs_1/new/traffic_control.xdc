# EE-210 (Digital Circuits) - Assignment 5
# Traffic Light Controller Constraints for ZedBoard

# ----------------------------------------------------------------------------
# Clock Source (100MHz)
# GCLK (Y9) is in Bank 13, which is fixed at 3.3V [cite: 20, 105]
# ----------------------------------------------------------------------------
set_property PACKAGE_PIN Y9   [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]

# ----------------------------------------------------------------------------
# Inputs (Buttons and Switches)
# ----------------------------------------------------------------------------
# Push Button BTNC (P16) for Reset
# Bank 34 is set to 1.8V by default [cite: 56, 102]
set_property PACKAGE_PIN P16  [get_ports reset]
set_property IOSTANDARD LVCMOS18 [get_ports reset]

# Switch SW0 (F22) for Side Road Sensor
# Bank 35 is set to 1.8V by default [cite: 63, 104]
set_property PACKAGE_PIN F22  [get_ports sensor]
set_property IOSTANDARD LVCMOS18 [get_ports sensor]

# ----------------------------------------------------------------------------
# Outputs (LEDs)
# All LEDs are in Bank 33, which is fixed at 3.3V [cite: 47, 48, 100]
# ----------------------------------------------------------------------------
# Main Road (R1) Lights
set_property PACKAGE_PIN T22  [get_ports R1_G]
set_property IOSTANDARD LVCMOS33 [get_ports R1_G]
set_property PACKAGE_PIN T21  [get_ports R1_Y]
set_property IOSTANDARD LVCMOS33 [get_ports R1_Y]
set_property PACKAGE_PIN U22  [get_ports R1_R]
set_property IOSTANDARD LVCMOS33 [get_ports R1_R]

# Side Road (R2) Lights
set_property PACKAGE_PIN U21  [get_ports R2_G]
set_property IOSTANDARD LVCMOS33 [get_ports R2_G]
set_property PACKAGE_PIN V22  [get_ports R2_Y]
set_property IOSTANDARD LVCMOS33 [get_ports R2_Y]
set_property PACKAGE_PIN W22  [get_ports R2_R]
set_property IOSTANDARD LVCMOS33 [get_ports R2_R]