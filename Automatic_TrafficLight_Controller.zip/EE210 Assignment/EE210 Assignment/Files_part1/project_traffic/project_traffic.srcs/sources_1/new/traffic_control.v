`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 27.10.2025 22:02:51
// Design Name: 
// Module Name: traffic_control
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module traffic_controller (
   
    input  wire clk,
    input  wire reset,
    
    
    input  wire sensor,     
    input  wire timer_done,
    
   
    output reg  R1_G,
    output reg  R1_Y,
    output reg  R1_R,
    output reg  R2_G,
    output reg  R2_Y,
    output reg  R2_R,
    
   
    output reg  timer_start,
    output reg  [1:0] timer_select
);

    localparam [2:0]
        S_R1_GREEN_START  = 3'b000,
        S_R1_GREEN_WAIT   = 3'b001,
        S_R1_YELLOW_START = 3'b010, 
        S_R1_YELLOW_WAIT  = 3'b011,
        S_R2_GREEN_START  = 3'b100,
        S_R2_GREEN_WAIT   = 3'b101,
        S_R2_YELLOW_START = 3'b110, 
        S_R2_YELLOW_WAIT  = 3'b111;

   
    localparam [1:0]
        SEL_30S = 2'b00, 
        SEL_20S = 2'b01, 
        SEL_5S  = 2'b10; 

  
    reg [2:0] current_state, next_state;


    always @(posedge clk or posedge reset) begin
        if (reset) begin
            current_state <= S_R1_GREEN_START;
        end else begin
            current_state <= next_state;
        end
    end

    always @(*) begin
   
        next_state = current_state; 
        
        case (current_state)
            S_R1_GREEN_START:
                next_state = S_R1_GREEN_WAIT;
                
            S_R1_GREEN_WAIT:
                if (timer_done)
                    next_state = S_R1_YELLOW_START;
                else
                    next_state = S_R1_GREEN_WAIT;

            S_R1_YELLOW_START:
                next_state = S_R1_YELLOW_WAIT;

            S_R1_YELLOW_WAIT:
                if (timer_done) begin
                   
                    if (sensor)
                        next_state = S_R2_GREEN_START; 
                    else
                        next_state = S_R1_GREEN_START; 
                end else begin
                    next_state = S_R1_YELLOW_WAIT;
                end
                
            S_R2_GREEN_START:
                next_state = S_R2_GREEN_WAIT;
                
            S_R2_GREEN_WAIT:
                if (timer_done)
                    next_state = S_R2_YELLOW_START;
                else
                    next_state = S_R2_GREEN_WAIT;

            S_R2_YELLOW_START:
                next_state = S_R2_YELLOW_WAIT;
                
            S_R2_YELLOW_WAIT:
                if (timer_done)
                    next_state = S_R1_GREEN_START; 
                else
                    next_state = S_R2_YELLOW_WAIT;
                    
            default:
                next_state = S_R1_GREEN_START;
        endcase
    end

    always @(*) begin
   
        R1_G = 1'b0;
        R1_Y = 1'b0;
        R1_R = 1'b1;
        R2_G = 1'b0;
        R2_Y = 1'b0;
        R2_R = 1'b1;
        timer_start  = 1'b0;
        timer_select = 2'bxx; 

        case (current_state)
            S_R1_GREEN_START: begin
           
                R1_G = 1'b1;
                R1_R = 1'b0;
                R2_R = 1'b1;
           
                timer_start  = 1'b1;
                timer_select = SEL_30S; 
            end
            
            S_R1_GREEN_WAIT: begin
               
                R1_G = 1'b1;
                R1_R = 1'b0;
                R2_R = 1'b1;
               
                timer_start = 1'b0;
            end

            S_R1_YELLOW_START: begin
              
                R1_Y = 1'b1;
                R1_R = 1'b0;
                R2_R = 1'b1;
              
                timer_start  = 1'b1;
                timer_select = SEL_5S; 
            end
            
            S_R1_YELLOW_WAIT: begin
            
                R1_Y = 1'b1;
                R1_R = 1'b0;
                R2_R = 1'b1;
             
                timer_start = 1'b0;
            end
                
            S_R2_GREEN_START: begin
               
                R1_R = 1'b1;
                R2_G = 1'b1;
                R2_R = 1'b0;
             
                timer_start  = 1'b1;
                timer_select = SEL_20S;
            end

            S_R2_GREEN_WAIT: begin
               
                R1_R = 1'b1;
                R2_G = 1'b1;
                R2_R = 1'b0;
                
                timer_start = 1'b0;
            end

            S_R2_YELLOW_START: begin
              
                R1_R = 1'b1;
                R2_Y = 1'b1;
                R2_R = 1'b0;
              
                timer_start  = 1'b1;
                timer_select = SEL_5S; 
            end

            S_R2_YELLOW_WAIT: begin
                
                R1_R = 1'b1;
                R2_Y = 1'b1;
                R2_R = 1'b0;
                
                timer_start = 1'b0;
            end
            
            default: begin
                
                R1_R = 1'b1;
                R2_R = 1'b1;
                timer_start = 1'b0;
            end
        endcase
    end

endmodule