`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 27.10.2025 22:04:21
// Design Name: 
// Module Name: traffic_control_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module traffic_control_tb;
    parameter CLK_PERIOD = 10;
    reg  clk;
    reg  reset;
    reg  sensor;
    reg  timer_done;

    wire R1_G, R1_Y, R1_R;
    wire R2_G, R2_Y, R2_R;
    wire timer_start;
    wire [1:0] timer_select;
    
    wire [2:0] current_state = UUT.current_state;

    traffic_controller UUT (
        .clk(clk),
        .reset(reset),
        .sensor(sensor),
        .timer_done(timer_done),
        .R1_G(R1_G),
        .R1_Y(R1_Y),
        .R1_R(R1_R),
        .R2_G(R2_G),
        .R2_Y(R2_Y),
        .R2_R(R2_R),
        .timer_start(timer_start),
        .timer_select(timer_select)
    );

    initial begin
        clk = 0;
    end
    always #(CLK_PERIOD / 2) begin
        clk = ~clk;
    end

    initial begin
       
        
        reset = 1;
        sensor = 0;
        timer_done = 0;
        #(CLK_PERIOD * 2);
        
        reset = 0;
        #(CLK_PERIOD);
        #(CLK_PERIOD); 

        
        sensor = 1; 
        #(CLK_PERIOD * 5);
        

        timer_done = 1;
        #(CLK_PERIOD); 
        timer_done = 0;
        #(CLK_PERIOD);
        #(CLK_PERIOD * 5);

       
        timer_done = 1;
        #(CLK_PERIOD); 
        timer_done = 0;
        #(CLK_PERIOD); 
        #(CLK_PERIOD * 5);
        
      
        timer_done = 1;
        #(CLK_PERIOD);
        timer_done = 0;
        #(CLK_PERIOD); 
        #(CLK_PERIOD * 5);
        
        timer_done = 1;
        #(CLK_PERIOD); 
        timer_done = 0;
        #(CLK_PERIOD);
        
        

       
        sensor = 0; 
        #(CLK_PERIOD * 5);
        
       
        timer_done = 1;
        #(CLK_PERIOD);
        timer_done = 0;
        #(CLK_PERIOD); 
        #(CLK_PERIOD * 5);

        timer_done = 1;
        #(CLK_PERIOD); 
        timer_done = 0;
        #(CLK_PERIOD);
        #(CLK_PERIOD * 5);
        
       
        sensor = 1; 
        timer_done = 1;
        #(CLK_PERIOD);
        timer_done = 0;
        #(CLK_PERIOD);
        reset = 1;
        #(CLK_PERIOD * 2);
        reset = 0;
        
        #(CLK_PERIOD);
        #(CLK_PERIOD);    
        #(CLK_PERIOD * 10);
        $finish;
    end

endmodule
