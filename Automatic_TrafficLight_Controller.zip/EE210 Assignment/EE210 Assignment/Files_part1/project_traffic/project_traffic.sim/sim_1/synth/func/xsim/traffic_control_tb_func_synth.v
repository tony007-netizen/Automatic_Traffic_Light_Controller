// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Mon Oct 27 22:17:03 2025
// Host        : HP running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file
//               C:/vivado_projects/project_traffic/project_traffic.sim/sim_1/synth/func/xsim/traffic_control_tb_func_synth.v
// Design      : traffic_controller
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* SEL_20S = "2'b01" *) (* SEL_30S = "2'b00" *) (* SEL_5S = "2'b10" *) 
(* S_R1_GREEN_START = "3'b000" *) (* S_R1_GREEN_WAIT = "3'b001" *) (* S_R1_YELLOW_START = "3'b010" *) 
(* S_R1_YELLOW_WAIT = "3'b011" *) (* S_R2_GREEN_START = "3'b100" *) (* S_R2_GREEN_WAIT = "3'b101" *) 
(* S_R2_YELLOW_START = "3'b110" *) (* S_R2_YELLOW_WAIT = "3'b111" *) 
(* NotValidForBitStream *)
module traffic_controller
   (clk,
    reset,
    sensor,
    timer_done,
    R1_G,
    R1_Y,
    R1_R,
    R2_G,
    R2_Y,
    R2_R,
    timer_start,
    timer_select);
  input clk;
  input reset;
  input sensor;
  input timer_done;
  output R1_G;
  output R1_Y;
  output R1_R;
  output R2_G;
  output R2_Y;
  output R2_R;
  output timer_start;
  output [1:0]timer_select;

  wire \FSM_sequential_current_state[0]_i_1_n_0 ;
  wire R1_G;
  wire R1_G_OBUF;
  wire R1_R;
  wire R1_R_OBUF;
  wire R1_Y;
  wire R1_Y_OBUF;
  wire R2_G;
  wire R2_R;
  wire R2_R_OBUF;
  wire R2_Y;
  wire R2_Y_OBUF;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [0:0]current_state;
  wire [2:1]next_state;
  wire reset;
  wire reset_IBUF;
  wire sensor;
  wire sensor_IBUF;
  wire timer_done;
  wire timer_done_IBUF;
  wire [1:0]timer_select;
  wire [1:0]timer_select_OBUF;
  wire timer_start;
  wire timer_start_OBUF;

  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \FSM_sequential_current_state[0]_i_1 
       (.I0(current_state),
        .I1(timer_done_IBUF),
        .O(\FSM_sequential_current_state[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    \FSM_sequential_current_state[1]_i_1 
       (.I0(timer_select_OBUF[1]),
        .I1(current_state),
        .I2(timer_done_IBUF),
        .O(next_state[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h6A2AAAAA)) 
    \FSM_sequential_current_state[2]_i_1 
       (.I0(R1_R_OBUF),
        .I1(timer_select_OBUF[1]),
        .I2(timer_done_IBUF),
        .I3(sensor_IBUF),
        .I4(current_state),
        .O(next_state[2]));
  (* FSM_ENCODED_STATES = "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_current_state_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(\FSM_sequential_current_state[0]_i_1_n_0 ),
        .Q(current_state));
  (* FSM_ENCODED_STATES = "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_current_state_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(next_state[1]),
        .Q(timer_select_OBUF[1]));
  (* FSM_ENCODED_STATES = "S_R1_GREEN_WAIT:001,S_R1_YELLOW_START:010,S_R1_YELLOW_WAIT:011,S_R2_GREEN_START:100,S_R2_GREEN_WAIT:101,S_R2_YELLOW_START:110,S_R2_YELLOW_WAIT:111,S_R1_GREEN_START:000" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_current_state_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_IBUF),
        .D(next_state[2]),
        .Q(R1_R_OBUF));
  OBUF R1_G_OBUF_inst
       (.I(R1_G_OBUF),
        .O(R1_G));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h1)) 
    R1_G_OBUF_inst_i_1
       (.I0(timer_select_OBUF[1]),
        .I1(R1_R_OBUF),
        .O(R1_G_OBUF));
  OBUF R1_R_OBUF_inst
       (.I(R1_R_OBUF),
        .O(R1_R));
  OBUF R1_Y_OBUF_inst
       (.I(R1_Y_OBUF),
        .O(R1_Y));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h2)) 
    R1_Y_OBUF_inst_i_1
       (.I0(timer_select_OBUF[1]),
        .I1(R1_R_OBUF),
        .O(R1_Y_OBUF));
  OBUF R2_G_OBUF_inst
       (.I(timer_select_OBUF[0]),
        .O(R2_G));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h2)) 
    R2_G_OBUF_inst_i_1
       (.I0(R1_R_OBUF),
        .I1(timer_select_OBUF[1]),
        .O(timer_select_OBUF[0]));
  OBUF R2_R_OBUF_inst
       (.I(R2_R_OBUF),
        .O(R2_R));
  LUT1 #(
    .INIT(2'h1)) 
    R2_R_OBUF_inst_i_1
       (.I0(R1_R_OBUF),
        .O(R2_R_OBUF));
  OBUF R2_Y_OBUF_inst
       (.I(R2_Y_OBUF),
        .O(R2_Y));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    R2_Y_OBUF_inst_i_1
       (.I0(timer_select_OBUF[1]),
        .I1(R1_R_OBUF),
        .O(R2_Y_OBUF));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  IBUF reset_IBUF_inst
       (.I(reset),
        .O(reset_IBUF));
  IBUF sensor_IBUF_inst
       (.I(sensor),
        .O(sensor_IBUF));
  IBUF timer_done_IBUF_inst
       (.I(timer_done),
        .O(timer_done_IBUF));
  OBUF \timer_select_OBUF[0]_inst 
       (.I(timer_select_OBUF[0]),
        .O(timer_select[0]));
  OBUF \timer_select_OBUF[1]_inst 
       (.I(timer_select_OBUF[1]),
        .O(timer_select[1]));
  OBUF timer_start_OBUF_inst
       (.I(timer_start_OBUF),
        .O(timer_start));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT1 #(
    .INIT(2'h1)) 
    timer_start_OBUF_inst_i_1
       (.I0(current_state),
        .O(timer_start_OBUF));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
